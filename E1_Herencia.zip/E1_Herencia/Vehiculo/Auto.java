package E_1;

public class Auto extends Vehiculo {

	String capacidad;

	public Auto(String marca, String modelo, int añoFabricacion, double vMaxima, String color, String capacidad) {
		super(marca, modelo, añoFabricacion, vMaxima, color);
		this.capacidad = capacidad;
	}
	
	
}
