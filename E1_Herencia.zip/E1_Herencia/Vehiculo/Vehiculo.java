package E_1;

public class Vehiculo {
	
	String marca;
	String modelo;
	int añoFabricacion;
	double vMaxima;
	String color;
	
	
	public Vehiculo(String marca, String modelo, int añoFabricacion, double vMaxima, String color) {
		this.marca = marca;
		this.modelo = modelo;
		this.añoFabricacion = añoFabricacion;
		this.vMaxima = vMaxima;
		this.color = color;
	}
	
	
	
}
