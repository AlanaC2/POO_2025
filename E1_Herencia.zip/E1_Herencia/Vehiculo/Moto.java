package E_1;

public class Moto extends Vehiculo{
	
	String tipo;

	public Moto(String marca, String modelo, int añoFabricacion, double vMaxima, String color, String tipo) {
		super(marca, modelo, añoFabricacion, vMaxima, color);
		this.tipo = tipo;
	}
	
	
}
