package E_1;

public class Estudiante extends Persona{

	String grado;
	double promedio;
	
	public Estudiante (String n, String a, int c, String f, int t, String grado, double promedio) {
		super(n, a, c, f, t);
		this.grado = grado;
		this.promedio = promedio;
	}
	
	
	
}
