package E_1;

public class Profesor extends Persona {

	double sueldo;
	String materia;
	
	
	public Profesor(String n, String a, int c, String f, int t, double sueldo, String materia) {
		super(n, a, c, f, t);
		this.sueldo = sueldo;
		this.materia = materia;
	}
	
	
}
