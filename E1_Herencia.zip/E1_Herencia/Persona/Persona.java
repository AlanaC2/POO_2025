package E_1;

public class Persona {

	String nombre;
	String apellido;
	int ci;
	String fechaNac;
	int telefono;
	
	
	public Persona(String nombre, String apellido, int ci, String fechaNac, int telefono) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.ci = ci;
		this.fechaNac = fechaNac;
		this.telefono = telefono;
	}
	
	
}
