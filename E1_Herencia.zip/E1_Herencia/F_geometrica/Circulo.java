package E_1;

public class Circulo extends Figura_Geometrica{

	double diametro;
	double radio;
	
	public Circulo(String n, double a, double p, int nu, double diametro, double radio) {
		super(n, a, p, nu);
		this.diametro = diametro;
		this.radio = radio;
	}

	
}
