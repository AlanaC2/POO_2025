package E_1;

public class Figura_Geometrica {

	String nombre;
	double area;
	double Perimetro;
	int numLados;
	
	public Figura_Geometrica(String nombre, double area, double perimetro, int numLados) {
		this.nombre = nombre;
		this.area = area;
		this.Perimetro = perimetro;
		this.numLados = numLados;
	}
	
	
}
