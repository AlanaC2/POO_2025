package E_1;

public class Triangulo extends Figura_Geometrica{

	String tipo;
	double base;
	double altura;
	double angulo;
	
	public Triangulo(String n, double a, double p, int nu, String tipo, double base, double altura, double angulo) {
		super(n, a, p, nu);
		this.tipo = tipo;
		this.base = base;
		this.altura = altura;
		this.angulo = angulo;
	}
	
	
}
